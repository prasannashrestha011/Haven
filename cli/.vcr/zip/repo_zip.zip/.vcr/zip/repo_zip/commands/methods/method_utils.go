package methods

import (
	"archive/zip"
	"fmt"
	"io"
	"main/configs"
	"os"
	"path/filepath"
)

func Init_Repo_Zip(tracked_list []string) {

	//fetching the parent directory containing .vcr folder
	configs.LoadParentFolder()
	//correctly mapping path variables to the .vcr path
	configs.PathConfigs()
	vcr_dir_path := configs.VcrRepoZip_dir_path

	outputZipPath := filepath.Join(vcr_dir_path, "repo_zip.zip")

	configs.VcrRepoZip_file_path = outputZipPath
	CreateRepoZip(tracked_list, outputZipPath)

}
func CreateRepoZip(tracked_list []string, zipPath string) error {
	zipFile, err := os.Create(zipPath)
	if err != nil {
		fmt.Println("Failed to create the zip file ", err.Error())
		return err
	}
	zipWriter := zip.NewWriter(zipFile)

	defer zipFile.Close()
	defer zipWriter.Close()

	for _, itemPath := range tracked_list {
		info, err := os.Stat(itemPath)
		if err != nil {
			fmt.Println("Failed to state the file ", err.Error())
			return nil
		}
		if info.IsDir() {
			header := &zip.FileHeader{
				Name:   itemPath + "/",
				Method: zip.Deflate,
			}
			header.SetMode(info.Mode())
			_, err = zipWriter.CreateHeader(header)
			if err != nil {
				fmt.Println("Failed to create zip header: ", err.Error())
				return err
			}
			continue
		}
		file, err := os.Open(itemPath)
		if err != nil {
			fmt.Println("Error opening the file ", err.Error())
			return err
		}
		defer file.Close()
		relPath := filepath.ToSlash(itemPath)
		header, err := zip.FileInfoHeader(info)
		if err != nil {
			fmt.Println("Failed to get file info header ", err.Error())
		}
		header.Name = relPath
		header.Method = zip.Deflate
		header.SetMode(info.Mode())
		writer, err := zipWriter.CreateHeader(header)
		if err != nil {
			fmt.Println("Failed to create zip header ", err.Error())
			return err
		}
		_, err = io.Copy(writer, file)
		if err != nil {
			fmt.Println("Failed to copy file to zip ", err.Error())
		}

	}

	return nil
}
