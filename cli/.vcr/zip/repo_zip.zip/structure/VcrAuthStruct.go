package structure

type VCR_AuthBody struct {
	Username           string
	Password           string
	AccessToken        string
	RefreshToken       string
	StorageReferenceID string
}
